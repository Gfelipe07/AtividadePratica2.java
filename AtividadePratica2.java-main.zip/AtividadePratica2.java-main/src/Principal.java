public class Principal {

    public static void main(String[] args) {

        // chamada de métodos para executar o programa
        Sistema.executar();

    }

}
